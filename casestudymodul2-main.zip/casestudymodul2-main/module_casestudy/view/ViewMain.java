package module_casestudy.view;


import module_casestudy.controller.MainFurama;

public class ViewMain {
    public static void main(String[] args) {
       MainFurama.displayMainMenu();
    }
}
