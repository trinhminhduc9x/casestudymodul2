package module_casestudy;

import module_casestudy.model.Booking;
import module_casestudy.model.facility.Facility;
import module_casestudy.model.person.Customer;
import module_casestudy.model.person.Employee;
import module_casestudy.util.ReadAndWriteCSV;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class test {
    private static final String PATH_FILE_VILLA = "src/module_casestudy/data/Villa.csv";
    private static final String PATH_FILE_EMPLOYEE = "src/module_casestudy/data/Employee.csv";
    private static final String PATH_FILE_BK = "src/module_casestudy/data/Booking.csv";
    private static final Scanner scanner = new Scanner(System.in);
    private static final String PATH_FILE_CUSTOMER = "src/module_casestudy/data/Customer.csv";
    private static final String EMAIL_REGEX = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
    private static final String PHONE_REGEX = "^(84|0[3|5|7|8|9])+([0-9]{8})$";
    private static final String IDNAME_REGEX = "^\\d{9}||\\d{12}$";
    private static final String SAlARY_REGEX = "^\\d+$";
    private static final String NAME_REGEX = "^[A-Z][a-z]+(\\s[A-Z][a-z]+)+$";
    List<Employee> employeeList = ReadAndWriteCSV.readEmployeeList(PATH_FILE_EMPLOYEE);
    private static final List<Customer> customerList = ReadAndWriteCSV.readCustomerList(PATH_FILE_CUSTOMER);

    public static void main(String[] args) {


    }

}