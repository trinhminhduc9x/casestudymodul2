package module_casestudy.util;

import module_casestudy.model.Booking;
import module_casestudy.model.Contract;
import module_casestudy.model.facility.Facility;
import module_casestudy.model.facility.House;
import module_casestudy.model.facility.Room;
import module_casestudy.model.facility.Villa;
import module_casestudy.model.person.Customer;
import module_casestudy.model.person.Employee;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class ReadAndWriteCSV {
    private static final String PATH_FILE = "src/module_casestudy/data/Facilitynew.csv";
    private static List<String> readObjectToCSV(String pathFile) {
        List<String> strings = new ArrayList<>();
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(pathFile));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                strings.add(line);
            }
        } catch (FileNotFoundException e) {
            System.err.println("File không tồn tại");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return strings;
    }

    private static void writeObjectToCSV(List<String> strings, String pathFile, boolean append) {
        FileWriter fileWriter;
        BufferedWriter bufferedWriter = null;
        try {
            fileWriter = new FileWriter(pathFile, append);
            bufferedWriter = new BufferedWriter(fileWriter);
            for (int i = 0; i < strings.size(); i++) {
                bufferedWriter.write(strings.get(i));
                bufferedWriter.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void writeEmployeeListToCSV(List<Employee> employeeList, String pathFile, boolean append) {
        List<String> stringList = new ArrayList<>();
        for (int i = 0; i < employeeList.size(); i++) {
            stringList.add(employeeList.get(i).getInfoToCSV());
        }
        writeObjectToCSV(stringList, pathFile, append);
    }

    public static List<Employee> readEmployeeList(String pathFile) {
        List<Employee> employeeList = new ArrayList<>();
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            employeeList.add(new Employee(array[0], array[1], LocalDate.parse(array[2]), array[3], array[4], array[5], array[6], array[7], array[8], array[9]));
        }
        return employeeList;
    }

    public static void writeCustomerListToCSV(List<Customer> customerList, String pathFile, boolean append) {
        List<String> stringList = new ArrayList<>();
        for (int i = 0; i < customerList.size(); i++) {
            stringList.add(customerList.get(i).getInfoToCSV());
        }
        writeObjectToCSV(stringList, pathFile, append);
    }

    public static List<Customer> readCustomerList(String pathFile) {
        List<Customer> customerList = new ArrayList<>();
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            customerList.add(new Customer(array[0], array[1], LocalDate.parse(array[2]), array[3], array[4], array[5], array[6], array[7], array[8]));
        }
        return customerList;
    }

    public static void writeListFacilityToCSV(Map<Facility, Integer> facilityIntegerMap, String pathFile, boolean append) {
        List<String> stringList = new ArrayList<>();
        Set<Facility> facilitySet = facilityIntegerMap.keySet();
        for (Facility key : facilitySet) {
            stringList.add(key.getInfoToCSV() + "," + facilityIntegerMap.get(key));
        }
        writeObjectToCSV(stringList, pathFile, append);
    }

    public static Map<Facility, Integer> readListFacilityVillaToCSV(String pathFile) {
        Map<Facility, Integer> facilityIntegerMap = new LinkedHashMap<>();
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            facilityIntegerMap.put(new Villa(array[0], array[1], Double.parseDouble(array[2]), Double.parseDouble(array[3]), Integer.parseInt(array[4]), array[5], array[6], Double.parseDouble(array[7]), Integer.parseInt(array[8])), Integer.parseInt(array[9]));
        }
        return facilityIntegerMap;
    }

    public static Map<Facility, Integer> readListFacilityRoomToCSV(String pathFile) {
        Map<Facility, Integer> facilityIntegerMap = new LinkedHashMap<>();
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            facilityIntegerMap.put(new Room(array[0], array[1], Double.parseDouble(array[2]), Double.parseDouble(array[3]), Integer.parseInt(array[4]), array[5], array[6]), Integer.parseInt(array[7]));
        }
        return facilityIntegerMap;
    }

    public static Map<Facility, Integer> readListFacilityHouseToCSV(String pathFile) {
        Map<Facility, Integer> facilityIntegerMap = new LinkedHashMap<>();
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            facilityIntegerMap.put(new House(array[0], array[1], Double.parseDouble(array[2]), Double.parseDouble(array[3]), Integer.parseInt(array[4]), array[5], array[6], Integer.parseInt(array[7])), Integer.parseInt(array[8]));
        }
        return facilityIntegerMap;
    }

    public static void writeBookingtoCSV(Set<Booking> bookingSet, String pathFile, boolean append) {
        List<String> stringList = new ArrayList<>();
        for (Booking b : bookingSet) {
            stringList.add(b.getInfoToCSV());
        }
        writeObjectToCSV(stringList, pathFile, append);
    }

    public static Set<Booking> readBookingtoCSV(String pathFile) {
        Set<Booking> bookingSet = new TreeSet<>(new BookingComparator());
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            bookingSet.add(new Booking(Integer.parseInt(array[0]), LocalDate.parse(array[1]), LocalDate.parse(array[2]), array[3], array[4]));
        }
        return bookingSet;
    }

    public static void writeContracttoCSV(List<Contract> contractList, String pathFile, boolean append) {
        List<String> stringList = new ArrayList<>();
        for (Contract c : contractList) {
            stringList.add(c.getInfoToCSV());
        }
        writeObjectToCSV(stringList, pathFile, append);
    }

    public static List<Contract> readContracttoCSV(String pathFile) {
        List<Contract> contractList = new ArrayList<>();
        List<String> strings = readObjectToCSV(pathFile);
        String[] array;
        for (int i = 0; i < strings.size(); i++) {
            array = strings.get(i).split(",");
            contractList.add(new Contract(array[0], array[1], array[2], array[3], array[4]));
        }
        return contractList;
    }

    public static Map<Facility, Integer> readfacilityIntegerMap(String pathFileVilla, String pathFileHouse, String pathFileRoom) {
        Map<Facility, Integer> facilityIntegerMap = new LinkedHashMap<>();
        Map<Facility, Integer> facilityVilla = readListFacilityVillaToCSV(pathFileVilla);
        Set<Facility> keySetV = facilityVilla.keySet();
        for (Facility key : keySetV) {
            facilityIntegerMap.put(key, facilityVilla.get(key));
        }
        Map<Facility, Integer> facilityHouse = readListFacilityHouseToCSV(pathFileHouse);
        Set<Facility> keySetH = facilityHouse.keySet();
        for (Facility key : keySetH) {
            facilityIntegerMap.put(key, facilityHouse.get(key));
        }

        Map<Facility, Integer> facilityRoom = readListFacilityRoomToCSV(pathFileRoom);
        Set<Facility> keySetR = facilityRoom.keySet();
        for (Facility key : keySetR) {
            facilityIntegerMap.put(key, facilityRoom.get(key));
        }
        writeListFacilityToCSV(facilityIntegerMap,PATH_FILE,false);
        return facilityIntegerMap;
    }
}












//    public static void writeBooking(Set<Booking> bookingSet, String pathFile) {
//        File file = new File(pathFile);
//        FileOutputStream fileOutputStream = null;
//        ObjectOutputStream objectOutputStream = null;
//        try {
//            fileOutputStream = new FileOutputStream(file);
//            objectOutputStream = new ObjectOutputStream(fileOutputStream);
//            objectOutputStream.writeObject(bookingSet);
//        } catch (IOException e) {
//            System.err.println("File lỗi rồi haha ");
//            e.printStackTrace();
//        } finally {
//            try {
//
//                fileOutputStream.close();
//                objectOutputStream.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//   }

//    public static Set<Booking> readBooking(String pathFile) {
//        Set<Booking> bookingSet = new TreeSet<>(new BookingComparator());
//        File file = new File(pathFile);
//        FileInputStream fileInputStream = null;
//        ObjectInputStream objectInputStream = null;
//        try {
//            if (file.length() > 0) {
//                fileInputStream = new FileInputStream(file);
//                objectInputStream = new ObjectInputStream(fileInputStream);
//                bookingSet = (Set<Booking>) objectInputStream.readObject();
//            }
//        } catch (FileNotFoundException e) {
//            System.err.println("File không tồn tại");
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (file.length() > 0) {
//                    fileInputStream.close();
//                    objectInputStream.close();
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return bookingSet;
//    }

//    public static Set<Booking> readFileBooking(String pathFile) {
//        Set<Booking> bookings = new TreeSet<>(new BookingComparator());
//        File file = new File(pathFile);
//        FileReader fileReader;
//        BufferedReader bufferedReader = null;
//        String line;
//        String[] array;
//
//        Map<Facility, Integer> facilityIntegerMap = new LinkedHashMap<>();
//        Map<Facility, Integer> facilityVilla = readListFacilityVillaToCSV("src/module_casestudy/model/facility/Villa.java");
//        Set<Facility> keySetV = facilityVilla.keySet();
//        for (Facility key : keySetV) {
//            facilityIntegerMap.put(key, facilityVilla.get(key));
//        }
//        Map<Facility, Integer> facilityHouse = readListFacilityHouseToCSV("src/module_casestudy/model/facility/House.java");
//        Set<Facility> keySetH = facilityHouse.keySet();
//        for (Facility key : keySetH) {
//            facilityIntegerMap.put(key, facilityHouse.get(key));
//        }
//        Map<Facility, Integer> facilityRoom = readListFacilityRoomToCSV("src/module_casestudy/model/facility/Room.java");
//        Set<Facility> keySetR = facilityRoom.keySet();
//        for (Facility key : keySetR) {
//            facilityIntegerMap.put(key, facilityRoom.get(key));
//        }
//        String customer = null;
//        String facility = null;
//        List<Customer> customers = readCustomerList("src/module_casestudy/model/person/Customer.java");
//        try {
//            fileReader = new FileReader(file);
//            bufferedReader = new BufferedReader(fileReader);
//            while ((line = bufferedReader.readLine()) != null) {
//                if (line.isEmpty()) continue;
//                array = line.split(",");
//                for (int i = 0; i < customers.size(); i++) {
//                    if (customers.get(i).getName().equals(array[3])) {
//                        customer = customers.get(i).getName();
//                    }
//                }
//                for (Map.Entry<Facility, Integer> entry : facilityIntegerMap.entrySet()) {
//                    if (entry.getKey().getNameService().equals(array[4])) {
//                        facility = entry.getKey().getNameService();
//                    }
//                }
//                bookings.add(new Booking(Integer.parseInt(array[0]), LocalDate.parse(array[1]), LocalDate.parse(array[2]),
//                        customer, facility));
//            }
//            bufferedReader.close();
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return bookings;// }
//
//}
