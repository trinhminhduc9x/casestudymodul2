package module_casestudy.service;

public interface BookingService extends IService{
}
