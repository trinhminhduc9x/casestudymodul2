package module_casestudy.service;

public interface ContactService extends IService{
}
