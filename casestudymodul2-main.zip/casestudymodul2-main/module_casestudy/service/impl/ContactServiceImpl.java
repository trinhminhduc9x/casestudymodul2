package module_casestudy.service.impl;

import module_casestudy.commen.CheckBooking;
import module_casestudy.commen.CheckFacility;
import module_casestudy.model.Booking;
import module_casestudy.model.Contract;
import module_casestudy.service.ContactService;
import module_casestudy.util.ReadAndWriteCSV;

import java.util.*;

public class ContactServiceImpl implements ContactService {
    private static final String PATH_FILE_BOOKING = "src/module_casestudy/data/Booking.csv";
    private static final String PATH_FILE_CONTACT = "src/module_casestudy/data/Contract.csv";
    static List<Contract> contractList = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    @Override
    public void display() {
        List<Contract> contractList = ReadAndWriteCSV.readContracttoCSV(PATH_FILE_CONTACT);
        if (contractList.isEmpty()) {
            System.out.println("Chưa có dữ liệu, mời bạn thêm vào.");
        } else {
            for (Contract c : contractList) {
                System.out.println(c.toString());
            }
        }
    }

    @Override
    public void add() {
        List<Contract> contractList = new ArrayList<>();
        Queue<Booking> bookingQueue = new LinkedList<>();
        Set<Booking> bookingSet = ReadAndWriteCSV.readBookingtoCSV(PATH_FILE_BOOKING);
        for (Booking b : bookingSet) {
            bookingQueue.add(b);
        }
        while (!bookingQueue.isEmpty()) {
            Booking booking = bookingQueue.poll();
            String customer = booking.getCustomer();
            System.out.println(" Đang tạo hợp đồng cho Booking có thông tin: " + booking.toString());
            System.out.println(" Đang tạo hợp đồng cho khách hàng có thông tin: " + customer);
            System.out.println(" Nhập id hợp đồng");
            String id = scanner.nextLine();

            String pre;
            do {
                System.out.println("Nhập số tiền trả trước: ");
                pre = scanner.nextLine();
                if (CheckBooking.checkContact(pre)) {
                    System.out.println(" nhập đúng số tiền trả trước: ");
                } else {
                    System.out.println(" nhập không đúng số tiền trả trước, yêu cầu nhập lại");
                }
            } while (!CheckBooking.checkContact(pre));

            String pay;
            do {
                System.out.println("Nhập số số chi phí: ");
                pay = scanner.nextLine();
                if (CheckBooking.checkContact(pay)) {
                    System.out.println(" nhập đúng số số chi phí: ");
                } else {
                    System.out.println(" nhập không đúng số chi phí, yêu cầu nhập lại");
                }
            } while (!CheckBooking.checkContact(pay));

            Contract contract = new Contract(id, booking.toString(), pre, pay, customer);
            System.out.println(" tạo hợp đồng thành công " + contract.toString());
            contractList.add(contract);

        }
        ReadAndWriteCSV.writeContracttoCSV(contractList, PATH_FILE_CONTACT, true);
    }

    @Override
    public void edit() {

    }


}
