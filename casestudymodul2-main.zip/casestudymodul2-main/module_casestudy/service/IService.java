package module_casestudy.service;

public interface IService {
    void display();
    void add();
    void edit();

}
