package module_casestudy.service;

public interface CustomerService extends IService{
}
