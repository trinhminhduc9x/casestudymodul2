package module_casestudy.service;

public interface EmployeeService extends IService{
}
