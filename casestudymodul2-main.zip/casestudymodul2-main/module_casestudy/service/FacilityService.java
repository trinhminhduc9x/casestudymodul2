package module_casestudy.service;

public interface FacilityService extends IService{
    void displayFacilityMaintenance();
}
