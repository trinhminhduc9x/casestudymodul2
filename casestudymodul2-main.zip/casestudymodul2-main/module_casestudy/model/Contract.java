package module_casestudy.model;

public class Contract {
    private String idContract;
    private String booking;
    private String pre;
    private String pay;
    private String customer;

    public Contract() {
    }

    public Contract(String idContract, String booking, String pre, String pay, String customer) {
        this.idContract = idContract;
        this.booking = booking;
        this.pre = pre;
        this.pay = pay;
        this.customer = customer;
    }
    public String getInfoToCSV() {
        return this.idContract +","+this.booking +","+ this.pre +","+this.pay +","+ this.customer;
    }
    public String getIdContract() {
        return idContract;
    }

    public void setIdContract(String idContract) {
        this.idContract = idContract;
    }

    public String getBooking() {
        return booking;
    }

    public void setBooking(String booking) {
        this.booking = booking;
    }

    public String getPre() {
        return pre;
    }

    public void setPre(String pre) {
        this.pre = pre;
    }

    public String getPay() {
        return pay;
    }

    public void setPay(String pay) {
        this.pay = pay;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "Contract{" +
                "idContract='" + idContract + '\'' +
                "; booking='" + booking + '\'' +
                "; pre='" + pre + '\'' +
                "; pay='" + pay + '\'' +
                "; customer='" + customer + '\'' +
                '}';
    }
}
