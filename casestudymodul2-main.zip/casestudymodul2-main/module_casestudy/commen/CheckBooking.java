package module_casestudy.commen;

import module_casestudy.model.Booking;
import module_casestudy.model.Contract;
import module_casestudy.model.person.Customer;
import module_casestudy.model.person.Employee;
import module_casestudy.util.ReadAndWriteCSV;

import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CheckBooking {
    private static final String PATH_FILE_BOOKING = "src/module_casestudy/data/Booking.csv";
    private static final String PATH_FILE_CONTACT = "src/module_casestudy/data/Contract.csv";
    private static final String EMAIL_REGEX = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
    private static final String PHONE_REGEX = "^(84|0[3|5|7|8|9])+([0-9]{8})$";
    private static final String IDNAME_REGEX = "^\\d{9}||\\d{12}$";
    private static final String SAlARY_REGEX = "^\\d+$";
    private static final String NAME_REGEX = "^[A-Z][a-z]+(\\s[A-Z][a-z]+)+$";
    private static final String NUMBER_REGEX = "^[0-9]+$";
    private static final Set<Booking> bookingSet = ReadAndWriteCSV.readBookingtoCSV(PATH_FILE_BOOKING);
    private static final List<Contract> contractList = ReadAndWriteCSV.readContracttoCSV(PATH_FILE_CONTACT);
    Scanner scanner = new Scanner(System.in);

    public static Boolean checkContact(String number) {
        Pattern pattern = Pattern.compile(NUMBER_REGEX);
        Matcher matcher = pattern.matcher(number);
       return matcher.matches();
    }


}
