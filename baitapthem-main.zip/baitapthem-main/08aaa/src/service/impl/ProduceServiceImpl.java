package service.impl;

import commom.Check;
import commom.IncreaseID;
import commom.NotFoundProductException;
import model.ExportProduce;
import model.ImportProduce;
import model.Produce;
import service.ProduceService;
import util.ReadAndWriteCSV;

import java.util.List;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProduceServiceImpl implements ProduceService {
    private static final String PRODUCT_PATH_CSV = "src/data/Products.csv";
    private static final Scanner scanner = new Scanner(System.in);

    @Override
    public void add() {

        boolean flag = true;
        do {
            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới sản phẩm nhập khẩu ." +
                    "\n 2.Thêm mới sản phẩm xuất khẩu " +
                    "\n 3. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới sản phẩm nhập khẩu");
                    addImportProduce();
                    break;
                case "2":
                    System.out.println("Thêm mới sản phẩm xuất khẩu");
                    addExportProduce();
                    break;
                case "3":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);

    }

    @Override
    public void display() {

        List<Produce> produceList = ReadAndWriteCSV.readProduceToCSV(PRODUCT_PATH_CSV);
        if (produceList.isEmpty()) {
            System.out.println("Chưa có dữ liệu, mời bạn thêm vào.");
        } else {
            for (Produce c : produceList) {
                System.out.println(c);
            }
        }


    }

    @Override
    public void search() {
        System.out.println(" nhập tên cần tìm va ma can tim ");
        int count = 0;
        String name = scanner.nextLine();
        List<Produce> produceList = ReadAndWriteCSV.readProduceToCSV(PRODUCT_PATH_CSV);
        for (Produce c : produceList) {
            if (c.getNameProduce().contains(name) || c.getNumberProduce().contains(name)) {
                System.out.println(c);
                count++;
            }
        }
        if (count == 0) {
            System.out.println(" không có tên cần tìm hoac ma can tim");
        }
    }

    @Override
    public void edit() {
        display();
        List<Produce> produceList = ReadAndWriteCSV.readProduceToCSV(PRODUCT_PATH_CSV);
        List<Produce>result = new ArrayList<>();
        int count = 0;
        do {
        String numberProduce = "";
        do {
            System.out.println("nhập mã sản phẩm ");
            numberProduce = scanner.nextLine();
            if (Check.checkEXName(numberProduce)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checkEXName(numberProduce));

        for (int i = 0; i < produceList.size(); i++) {
            if (produceList.get(i).getNumberProduce().equals(numberProduce)) {
                String choose;
                result.add(produceList.get(i));
                do {
                    System.out.println("Chức năng của hệ thống " +
                            "\n 1.yes." +
                            "\n 2.no");
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("Chọn chức năng");
                    choose = scanner.nextLine();
                    switch (choose) {
                        case "1":
                            produceList.remove(i);
                            break;
                        case "2":
                            return;
                        default:
                            System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
                    }
                } while (!choose.equals("1"));
                count++;
            }
        }
//        if (result.isEmpty()){
//            try {
//                throw new NotFoundProductException("Khong tim thay");
//            } catch (NotFoundProductException e) {
//                e.printStackTrace();
//            }
//        }
        if (count == 0) {
            try {
                throw new NotFoundProductException("Khong tim thay");
            } catch (NotFoundProductException e) {
                e.printStackTrace();
            }
            System.out.println(" nhập không đúng mã ");
        }
        } while (count==0);
        ReadAndWriteCSV.writeProduceToCSV(produceList, PRODUCT_PATH_CSV, false);
    }

    public void addExportProduce() {
        int id = IncreaseID.increaseID();

        String numberProduce = "";
        do {
            System.out.println("nhập mã sản phẩm ");
            numberProduce = scanner.nextLine();
            if (Check.checRegexMaSP(numberProduce)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMaSP(numberProduce));


        String name = "";
        do {
            System.out.println("nhập tên sản phẩm bắt đầu bằng chữ hoa");
            name = scanner.nextLine();
            if (Check.checkName(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(name));


        String giaBan = "";
        do {
            System.out.println("nhập giá bán");
            giaBan = scanner.nextLine();
            if (Check.checRegexNumber(giaBan)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(giaBan));

        int costByProduce = Integer.parseInt(giaBan);


        String soLuong = "";
        do {
            System.out.println("nhập số lượng");
            soLuong = scanner.nextLine();
            if (Check.checRegexNumber(soLuong)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(soLuong));

        int amountProduce = Integer.parseInt(soLuong);


        String manufacturerProduce = "";
        do {
            System.out.println("nhập nhà sản xuất bắt đầu bằng chữ hoa ");
            manufacturerProduce = scanner.nextLine();
            if (Check.checkName(manufacturerProduce)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(manufacturerProduce));


        String giaXuatKhau = "";
        do {
            System.out.println("nhập giá xuat khau");
            giaXuatKhau = scanner.nextLine();
            if (Check.checRegexNumber(giaXuatKhau)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(giaXuatKhau));

        int costExportProduce = Integer.parseInt(giaXuatKhau);


        String nationExportProduce = "";
        do {
            System.out.println("nhập tên quốc gia sản xuất bắt đầu bằng chữ hoa");
            nationExportProduce = scanner.nextLine();
            if (Check.checkName(nationExportProduce)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(nationExportProduce));
        ;


        List<Produce> produceList = new ArrayList<>();
        Produce produce = new ExportProduce(id, numberProduce, name, costByProduce, amountProduce, manufacturerProduce, costExportProduce, nationExportProduce);
        produceList.add(produce);
        ReadAndWriteCSV.writeProduceToCSV(produceList, PRODUCT_PATH_CSV, true);

    }


    public void addImportProduce() {
        int id = IncreaseID.increaseID();

        String numberProduce = "";
        do {
            System.out.println("nhập mã sản phẩm ");
            numberProduce = scanner.nextLine();
            if (Check.checRegexMaSP(numberProduce)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMaSP(numberProduce));


        String name = "";
        do {
            System.out.println("nhập tên sản phẩm bắt đầu bằng chữ hoa");
            name = scanner.nextLine();
            if (Check.checkName(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(name));


        String giaBan = "";
        do {
            System.out.println("nhập giá bán");
            giaBan = scanner.nextLine();
            if (Check.checRegexNumber(giaBan)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(giaBan));

        int costByProduce = Integer.parseInt(giaBan);


        String soLuong = "";
        do {
            System.out.println("nhập số lượng");
            soLuong = scanner.nextLine();
            if (Check.checRegexNumber(soLuong)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(soLuong));

        int amountProduce = Integer.parseInt(soLuong);


        String manufacturerProduce = "";
        do {
            System.out.println("nhập nhà sản xuất bắt đầu bằng chữ hoa ");
            manufacturerProduce = scanner.nextLine();
            if (Check.checkName(manufacturerProduce)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(manufacturerProduce));


        String giaNhapKhau = "";
        do {
            System.out.println("nhập giá nhap khau");
            giaNhapKhau = scanner.nextLine();
            if (Check.checRegexNumber(giaNhapKhau)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(giaNhapKhau));

        int costImportProduce = Integer.parseInt(giaNhapKhau);


        String cityImportProduce = "";
        do {
            System.out.println("nhập tên thanh pho bắt đầu bằng chữ hoa");
            cityImportProduce = scanner.nextLine();
            if (Check.checkName(cityImportProduce)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(cityImportProduce));


        String thue = "";
        do {
            System.out.println("nhập giá nhap khau");
            thue = scanner.nextLine();
            if (Check.checRegexNumber(thue)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(thue));

        int taxImportProduce = Integer.parseInt(thue);


        List<Produce> produceList = new ArrayList<>();
        Produce produce = new ImportProduce(id, numberProduce, name, costByProduce, amountProduce, manufacturerProduce, costImportProduce, cityImportProduce, taxImportProduce);
        produceList.add(produce);
        ReadAndWriteCSV.writeProduceToCSV(produceList, PRODUCT_PATH_CSV, true);

    }


}
