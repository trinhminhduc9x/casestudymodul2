import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class test {
    private static final String PHONE_PATH_CSV = "src/data/Mobiles.csv";
    private static final Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        LocalDate dateNow = LocalDate.now();
        boolean check;
        LocalDate startDay = null;
        do {
            try {
                System.out.println("nhập ngày kết thúc bảo hành theo dd/MM/yyyy");
                String day = scanner.nextLine();
                startDay = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                Period periodToNextJavaRelease = Period.between(dateNow,startDay);
                if (periodToNextJavaRelease.getDays() < 730&&periodToNextJavaRelease.getDays() > 0) {
                    System.out.println("bạn đã nhập đúng ");
                    break;
                }
                check = false;
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            } catch (DateTimeParseException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại,Thời gian bảo hành là số dương, tương ứng với số ngày được bảo hành không quá 730 ngày (2 năm). ");
                check = false;
            }
        } while (!check);

    }
}
