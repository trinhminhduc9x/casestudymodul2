package controller;


import commom.NotFoundProductException;
import service.PhoneService;
import service.impl.PhoneServiceImpl;

import java.util.Scanner;

public class Main {
    public static void displayMainMenu() {
        PhoneService phoneService;
        boolean flag = true;
        do {
            phoneService = new PhoneServiceImpl();

            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới." +
                    "\n 2.Xóa  " +
                    "\n 3.Xem danh sách  " +
                    "\n 4.Tìm kiếm " +
                    "\n 5. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới.");
                    phoneService.add();
                    break;
                case "2":
                    System.out.println("Xóa thông tin ");
                    try {
                        phoneService.edit();
                    } catch (NotFoundProductException e) {
                        e.printStackTrace();
                    }
                    break;
                case "3":
                    System.out.println("Xem danh sách ");
                    phoneService.display();
                    break;
                case "4":
                    System.out.println("Tìm kiếm ");
                    phoneService.search();
                    break;
                case "5":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);
    }
}
