package model;

public abstract class  Phone {
    private int id;
    private String namePhone ;
    private int pricePhone ;
    private int amountPhone ;
    private String producerPhone ;

    public Phone(int id, String namePhone, int pricePhone, int amountPhone, String producerPhone) {
        this.id = id;
        this.namePhone = namePhone;
        this.pricePhone = pricePhone;
        this.amountPhone = amountPhone;
        this.producerPhone = producerPhone;
    }

    public String getInfoToCSV() {
        return this.id + "," + this.namePhone + "," + this.pricePhone + "," + this.amountPhone + "," + this.producerPhone;
    }
    public Phone() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNamePhone() {
        return namePhone;
    }

    public void setNamePhone(String namePhone) {
        this.namePhone = namePhone;
    }

    public int getPricePhone() {
        return pricePhone;
    }

    public void setPricePhone(int pricePhone) {
        this.pricePhone = pricePhone;
    }

    public int getAmountPhone() {
        return amountPhone;
    }

    public void setAmountPhone(int amountPhone) {
        this.amountPhone = amountPhone;
    }

    public String getProducerPhone() {
        return producerPhone;
    }

    public void setProducerPhone(String producerPhone) {
        this.producerPhone = producerPhone;
    }

    @Override
    public String toString() {
        return "id=" + id +
                ", namePhone='" + namePhone + '\'' +
                ", pricePhone=" + pricePhone +
                ", amountPhone=" + amountPhone +
                ", producerPhone='" + producerPhone + '\'' ;
    }
}
