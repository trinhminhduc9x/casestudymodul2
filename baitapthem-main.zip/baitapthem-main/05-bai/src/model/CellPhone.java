package model;

public class CellPhone extends  Phone{
    private String portableCountry;
    private String status;

    public CellPhone(int id, String namePhone, int pricePhone, int amountPhone, String producerPhone, String portableCountry, String status) {
        super(id, namePhone, pricePhone, amountPhone, producerPhone);
        this.portableCountry = portableCountry;
        this.status = status;
    }

    @Override
    public String getInfoToCSV() {
        return super.getInfoToCSV() + "," + this.portableCountry+ "," + this.status ;
    }

    public CellPhone(String portableCountry, String status) {
        this.portableCountry = portableCountry;
        this.status = status;
    }

    public CellPhone() {
    }

    public String getPortableCountry() {
        return portableCountry;
    }

    public void setPortableCountry(String portableCountry) {
        this.portableCountry = portableCountry;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "CellPhone{" + super.toString()+
                "portableCountry='" + portableCountry + '\'' +
                ", status='" + status + '\'' +
                "} " ;
    }
}
