package model;

import java.time.LocalDate;

public class GenuinePhone extends Phone {
    private LocalDate warrantyPeriod;
    private String warrantyCoverage;

    public GenuinePhone(int id, String namePhone, int pricePhone, int amountPhone, String producerPhone, LocalDate warrantyPeriod, String warrantyCoverage) {
        super(id, namePhone, pricePhone, amountPhone, producerPhone);
        this.warrantyPeriod = warrantyPeriod;
        this.warrantyCoverage = warrantyCoverage;
    }

    @Override
    public String getInfoToCSV() {
        return super.getInfoToCSV()  + "," + this.warrantyPeriod+ "," + this.warrantyCoverage ;
    }

    public GenuinePhone(LocalDate warrantyPeriod, String warrantyCoverage) {
        this.warrantyPeriod = warrantyPeriod;
        this.warrantyCoverage = warrantyCoverage;
    }

    public GenuinePhone() {
    }

    public LocalDate getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(LocalDate warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }

    public String getWarrantyCoverage() {
        return warrantyCoverage;
    }

    public void setWarrantyCoverage(String warrantyCoverage) {
        this.warrantyCoverage = warrantyCoverage;
    }

    @Override
    public String toString() {
        return "GenuinePhone{" + super.toString()+
                "warrantyPeriod=" + warrantyPeriod +
                ", warrantyCoverage='" + warrantyCoverage + '\'' +
                "} " ;
    }
}
