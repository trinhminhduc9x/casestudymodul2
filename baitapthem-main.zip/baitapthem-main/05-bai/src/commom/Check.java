package commom;

import model.Phone;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Check {
    private static final String PHONE_PATH_CSV = "src/data/Mobiles.csv";
    private static final String NAME_REGEX = "^[A-Z]\\w+$";
    private static final String NUMBER_REGEX = "^\\d+$";
//    private static final String COUNTRY_REGEX = "[^Viet Nam]";
    private static final String COUNTRY_REGEX = "[^(Viet Nam|VN)]";

    public static Boolean checkNamePhone(String name) {
        List<Phone> phoneList = ReadAndWriteCSV.readPhoneToCSV(PHONE_PATH_CSV);
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        boolean check = false;
        if (matcher.matches()) {
            check = true;
            for (int i = 0; i < phoneList.size(); i++) {
                if (name.equals(phoneList.get(i).getNamePhone())) {
                    check = false;
                    break;
                }
            }
        }
        return check;
    }
    public static Boolean checRegexNumber(String name) {
        return name.matches(NUMBER_REGEX);
    }
    public static Boolean checRegexConutry(String name) {
        return name.matches(COUNTRY_REGEX);
    }


}
