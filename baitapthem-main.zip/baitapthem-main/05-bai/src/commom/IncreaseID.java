package commom;

import model.Phone;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.Scanner;

public class IncreaseID {
    private static final String PHONE_PATH_CSV = "src/data/Mobiles.csv";
  private static final Scanner scanner = new Scanner(System.in);
    public static int increaseID() {
        List<Phone> bankAccountList = ReadAndWriteCSV.readPhoneToCSV(PHONE_PATH_CSV);
        int stt;
        if (bankAccountList.isEmpty()) {
            stt=1;
        } else {
            stt=bankAccountList.get(bankAccountList.size() - 1).getId() + 1;
        }
        return stt;
    }

}
