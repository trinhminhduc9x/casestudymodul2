package util;
import model.CellPhone;
import model.GenuinePhone;
import model.Phone;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public class ReadAndWriteCSV {
    public static List<String> readObjectToCSV(String pathFile) {
        List<String> list = new ArrayList<>();
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(pathFile));
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                list.add(line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    private static void writeObjectToCSV(List<String> list, String pathFile, boolean append) {
        BufferedWriter bufferedWriter = null;
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(pathFile, append));
            for (int i = 0; i < list.size(); i++) {
                bufferedWriter.write(list.get(i));
                bufferedWriter.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static List<Phone> readPhoneToCSV(String pathFile) {
        List<Phone> phoneList = new ArrayList<>();
        List<String> list = readObjectToCSV(pathFile);
        String[] arr;
        for (int i = 0; i < list.size(); i++) {
            arr = list.get(i).split(",");
            if (arr[6].contains("Quoc") ){
                phoneList.add(new GenuinePhone(Integer.parseInt(arr[0]), arr[1],Integer.parseInt(arr[2]), Integer.parseInt(arr[3]),  arr[4],LocalDate.parse(arr[5]),arr[6]));
            } else if (arr[6].contains("sua chua")) {
                phoneList.add(new CellPhone(Integer.parseInt(arr[0]), arr[1],Integer.parseInt(arr[2]), Integer.parseInt(arr[3]),  arr[4],arr[5],arr[6]));
            }
        }
        return phoneList;
    }

    public static void writePhoneToCSV(List<Phone> phoneList, String pathFile, boolean append) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < phoneList.size(); i++) {
            list.add(phoneList.get(i).getInfoToCSV());
        }
        writeObjectToCSV(list, pathFile, append);
    }

}
