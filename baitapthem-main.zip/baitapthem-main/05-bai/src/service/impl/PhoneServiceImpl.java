package service.impl;

import commom.Check;
import commom.IncreaseID;
import commom.NotFoundProductException;
import model.CellPhone;
import model.GenuinePhone;
import model.Phone;
import service.PhoneService;
import util.ReadAndWriteCSV;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PhoneServiceImpl implements PhoneService {
    private static final String PHONE_PATH_CSV = "src/data/Mobiles.csv";
    private static final Scanner scanner = new Scanner(System.in);

    @Override
    public void add() {
        boolean flag = true;
        do {
            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới điện thoại chính hãng." +
                    "\n 2.Thêm mới điện thoại sách tay" +
                    "\n 3. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới điện thoại chính hãng");
                    addGenuinePhone();
                    break;
                case "2":
                    System.out.println("Thêm mới điện thoại sách tay");
                    addCellPhone();
                    break;
                case "3":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);
    }

    @Override
    public void display() {
        List<Phone> phoneList = ReadAndWriteCSV.readPhoneToCSV(PHONE_PATH_CSV);
        for (Phone c : phoneList) {
            System.out.println(c);
        }
    }

    @Override
    public void search() {

        System.out.println(" nhập tên cần tìm ");
        int count = 0;
        String name = scanner.nextLine();
        List<Phone> phoneList = ReadAndWriteCSV.readPhoneToCSV(PHONE_PATH_CSV);
        for (Phone c : phoneList) {
            if (c.getNamePhone().contains(name) || String.valueOf(c.getId()).contains(name)) {
                System.out.println(c);
                count++;
            }
        }
        if (count == 0) {
            System.out.println(" không có tên cần tìm");
        }
    }


    @Override
    public void edit() throws NotFoundProductException {
        List<Phone> phoneList = ReadAndWriteCSV.readPhoneToCSV(PHONE_PATH_CSV);
        int delete;
        while (true) {
            try {
                System.out.println("nhap id điện thoại can xoa ");
                delete = Integer.parseInt(scanner.nextLine());
                System.out.println("bạn đã nhập đúng ");
                break;
            } catch (NumberFormatException e) {

                throw new NotFoundProductException("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        }

        int count = 0;
        for (int i = 0; i < phoneList.size(); i++) {
            if (phoneList.get(i).getId() == delete) {

                String choose;
                do {
                    System.out.println("Chức năng của hệ thống " +
                            "\n 1.yes." +
                            "\n 2.no");
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("Chọn chức năng");
                  choose = scanner.nextLine();
                    switch (choose) {
                        case "1":
                            phoneList.remove(i);
                            break;
                        case "2":
                            return;
                        default:
                            System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
                    }
                } while (!choose.equals("1"));
                count++;
                break;
            }
        }
        if (count == 0) {
            System.out.println(" nhập không đúng mã ");
        }
        ReadAndWriteCSV.writePhoneToCSV(phoneList, PHONE_PATH_CSV, false);
    }

    public void addGenuinePhone() {
        int id = IncreaseID.increaseID();

        String name = "";
        do {
            System.out.println("nhập tên");
            name = scanner.nextLine();
            if (Check.checkNamePhone(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkNamePhone(name));


        String so = "";
        do {
            System.out.println("nhập giá bán");
            so = scanner.nextLine();
            if (Check.checRegexNumber(so)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(so));

        int pricePhone = Integer.parseInt(so);


        String soLuong = "";
        do {
            System.out.println("nhập Số lượngg");
            soLuong = scanner.nextLine();
            if (Check.checRegexNumber(soLuong)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(soLuong));

        int amountPhone = Integer.parseInt(soLuong);


        System.out.println("nhập nhà sản xuất");
        String producerPhone = scanner.nextLine();


        LocalDate dateNow = LocalDate.now();
        boolean check;
        LocalDate startDay = null;
        do {
            try {
                System.out.println("nhập ngày kết thúc bảo hành theo dd/MM/yyyy");
                String day = scanner.nextLine();
                startDay = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                Period periodToNextJavaRelease = Period.between(dateNow, startDay);
                if (periodToNextJavaRelease.getDays() < 730 && periodToNextJavaRelease.getDays() > 0) {
                    System.out.println("bạn đã nhập đúng ");
                    break;
                }
                check = false;
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            } catch (DateTimeParseException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại,Thời gian bảo hành là số dương, tương ứng với số ngày được bảo hành không quá 730 ngày (2 năm). ");
                check = false;
            }
        } while (!check);


        String warrantyCoverage = "";
        do {
            System.out.println("chọn phạm vi " +
                    "\n 1.Toan Quoc" +
                    "\n 2.Quoc Te");
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    warrantyCoverage = "Toan Quoc";
                    break;
                case "2":
                    warrantyCoverage = "Quoc Te";
                    break;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (warrantyCoverage.equals(""));


        List<Phone> phoneList = new ArrayList<>();
        Phone phone = new GenuinePhone(id, name, pricePhone, amountPhone, producerPhone, startDay, warrantyCoverage);
        phoneList.add(phone);
        ReadAndWriteCSV.writePhoneToCSV(phoneList, PHONE_PATH_CSV, true);

    }

    public void addCellPhone() {
        int id = IncreaseID.increaseID();

        String name = "";
        do {
            System.out.println("nhập tên");
            name = scanner.nextLine();
            if (Check.checkNamePhone(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkNamePhone(name));


        String so = "";
        do {
            System.out.println("nhập giá bán");
            so = scanner.nextLine();
            if (Check.checRegexNumber(so)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(so));

        int pricePhone = Integer.parseInt(so);


        String soLuong = "";
        do {
            System.out.println("nhập Số lượngg");
            soLuong = scanner.nextLine();
            if (Check.checRegexNumber(soLuong)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(soLuong));

        int amountPhone = Integer.parseInt(soLuong);


        System.out.println("nhập nhà sản xuất");
        String producerPhone = scanner.nextLine();


        String portableCountry = "";
        do {
            System.out.println("nhập nhà quốc gia sách tay");
            portableCountry = scanner.nextLine();
            if (Check.checRegexConutry(portableCountry)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexConutry(portableCountry));





        String status = "";
        do {
            System.out.println("chọn trạng thái " +
                    "\n 1.Da sua chua" +
                    "\n 2.Chua sua chua");
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    status = "Da sua chua";
                    break;
                case "2":
                    status = "Chua sua chua";
                    break;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (status.equals(""));


        List<Phone> phoneList = new ArrayList<>();
        Phone phone = new CellPhone(id, name, pricePhone, amountPhone, producerPhone, portableCountry, status);
        phoneList.add(phone);
        ReadAndWriteCSV.writePhoneToCSV(phoneList, PHONE_PATH_CSV, true);

    }
}
