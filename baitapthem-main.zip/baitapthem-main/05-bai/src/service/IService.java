package service;

import commom.NotFoundProductException;

public interface IService {
    void add();
    void display();
    void search();
    void edit() throws NotFoundProductException;
}
