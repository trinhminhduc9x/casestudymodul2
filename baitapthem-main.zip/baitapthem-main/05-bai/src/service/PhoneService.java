package service;

public interface PhoneService extends IService {
}
