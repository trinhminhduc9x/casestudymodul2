package model;

public class HandbookPhone extends Phone{

}
