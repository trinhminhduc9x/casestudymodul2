package model;

public abstract class Phone {

}
