package model;

public class GenuinePhone extends Phone {

}
