package service;

public interface ISevice {
    void add();
    void display();
    void edit();
    void delete();
}
