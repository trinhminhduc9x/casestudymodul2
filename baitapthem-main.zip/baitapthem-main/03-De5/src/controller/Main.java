package controller;

import service.BankServica;
import service.impl.BankServicaImpl;

import java.util.Scanner;

public class Main {
    public static void displayMainMenu() {
        BankServica bankServica;
//        ServicerHoaDon servicerHoaDon;
        boolean flag = true;
        do {
            bankServica = new BankServicaImpl();
//            servicerHoaDon = new ServicerHoaDon();
            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới khách hàng." +
                    "\n 2.Xóa thông tin khách hàng" +
                    "\n 3.Xem danh sách khách hàng " +
                    "\n 4.Tìm kiếm khách hàng" +
                    "\n 5. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới khách hàng.");
                    bankServica.themmoi();
                    break;
                case "2":
                    System.out.println("Xóa thông tin khách hàng");
                    bankServica.chinhsua();
                    break;
                case "3":
                    System.out.println("Xem danh sách khách hàng");
                    bankServica.hienthi();
                    break;
                case "4":
                    System.out.println("Tìm kiếm khách hàng");
                    bankServica.timkiem();
                    break;
                case "5":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);
    }
}
