package service;

public interface PayServica extends IService{
}
