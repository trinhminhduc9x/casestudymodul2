package service;

public interface SaveServica extends IService{
}
