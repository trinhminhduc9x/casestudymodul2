package service.impl;

import model.BankAccount;
import service.BankServica;
import service.PayServica;
import service.SaveServica;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.Scanner;

public class BankServicaImpl implements BankServica {
    private static final String Bank_PATH_CSV = "src/data/BankAccounts.csv";
    private static final Scanner SCANNER = new Scanner(System.in);

    @Override
    public void themmoi() {
        SaveServica saveServica;
        PayServica payServica;
        boolean flag = true;
        do {
            payServica = new PayServicaImpl();
            saveServica = new SaveServicaImpl();
            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới tài khoản lưu trữ." +
                    "\n 2.Thêm mới tài khoản thanh toán" +
                    "\n 3. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới  tài khoản lưu trữ");
                    saveServica.themmoi();
                    break;
                case "2":
                    System.out.println("Thêm mới tài khoản thanh toán");
                    payServica.themmoi();
                    break;
                case "3":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);
    }

    @Override
    public void hienthi() {
        List<BankAccount> bankAccountList = ReadAndWriteCSV.readBankAccountToCSV(Bank_PATH_CSV);
        for (BankAccount c : bankAccountList) {
            System.out.println(c);
        }
    }

    @Override
    public void timkiem() {
        System.out.println(" nhập tên cần tìm ");
        int count = 0;
        String name = SCANNER.nextLine();
        List<BankAccount> bankAccountList = ReadAndWriteCSV.readBankAccountToCSV(Bank_PATH_CSV);
        for (BankAccount c : bankAccountList) {
            if (c.getNameAccount().contains(name) || String.valueOf(c.getCodeAccount()).contains(name)) {
                System.out.println(c);
                count++;
            }
        }
        if (count == 0) {
            System.out.println(" không có tên cần tìm");
        }
    }

    @Override
    public void chinhsua() {
        hienthi();
        List<BankAccount> bankAccountList = ReadAndWriteCSV.readBankAccountToCSV(Bank_PATH_CSV);
        int delete ;
        while (true) {
            try {
                System.out.println("nhap hoc vien can xoa hoac ma");
                delete = Integer.parseInt(SCANNER.nextLine());
                System.out.println("bạn đã nhập đúng ");
                break;
            } catch (NumberFormatException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        }

        int count = 0;
        for (int i = 0; i < bankAccountList.size(); i++) {
            if (bankAccountList.get(i).getCodeAccount() == delete) {
                bankAccountList.remove(i);
                count++;
            }
        }
        if (count == 0) {
            System.out.println(" nhập không đúng mã ");
        }
        ReadAndWriteCSV.writeBankAccountToCSV(bankAccountList, Bank_PATH_CSV, false);

    }
}
