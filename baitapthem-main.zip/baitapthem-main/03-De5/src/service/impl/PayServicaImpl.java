package service.impl;

import commom.Check;
import commom.IncreaseID;
import model.BankAccount;
import model.PaymentAccount;
import service.BankServica;
import service.PayServica;
import util.ReadAndWriteCSV;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PayServicaImpl implements PayServica {
    private static final String Bank_PATH_CSV = "src/data/BankAccounts.csv";
    static Scanner scanner = new Scanner(System.in);
    @Override
    public void themmoi() {
        int id= IncreaseID.increaseID();



        String code1 = "";
        do {
            System.out.println("nhập Số thẻ sử dụng");
            code1 = scanner.nextLine();
            if (Check.checRegexMTK(code1)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMTK(code1));
        int code = Integer.parseInt(code1);




//        while (true) {
//            try {
//                System.out.println("nhập Mã tài khoảng");
//                code = Integer.parseInt(scanner.nextLine());
//                System.out.println("bạn đã nhập đúng ");
//                break;
//            } catch (NumberFormatException e) {
//                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
//            }
//        }


        String name = "";
        do {
            System.out.println("nhập tên");
            name = scanner.nextLine();
            if (Check.checkKhachHangName(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkKhachHangName(name));







        LocalDate dateNow = LocalDate.now();
        boolean check;
        LocalDate startDay = null;
        do {
            try {
                System.out.println("nhập ngay bắt đầu theo dd/MM/yyyy");
                String day = scanner.nextLine();
                startDay = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                Period periodToNextJavaRelease = Period.between(startDay, dateNow);
                if (periodToNextJavaRelease.getYears() < 100 ) {
                    System.out.println("bạn đã nhập đúng ");
                    break;
                }
                check = false;
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            } catch (DateTimeParseException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
                check = false;
            }
        } while (!check);


        String so = "";
        do {
            System.out.println("nhập Số thẻ sử dụng");
            so = scanner.nextLine();
            if (Check.checRegexNumber(so)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(so));


        long numberCart = Long.parseLong(so);

//        int money ;
//        while (true) {
//            try {
//                System.out.println("nhập Số tiền trong tài khoảng");
//                money = Integer.parseInt(scanner.nextLine());
//                System.out.println("bạn đã nhập đúng ");
//                break;
//            } catch (NumberFormatException e) {
//                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
//            }
//        }

        String money1 = "";
        do {
            System.out.println("nhập tien sử dụng");
            money1 = scanner.nextLine();
            if (Check.checRegexNB(money1)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNB(money1));
        int money= Integer.parseInt(money1);






        List<BankAccount> bankAccountList = new ArrayList<>();
        BankAccount bankAccount = new PaymentAccount(id,code, name, startDay,numberCart,money);
        bankAccountList.add(bankAccount);
        ReadAndWriteCSV.writeBankAccountToCSV(bankAccountList, Bank_PATH_CSV, true);

    }

    @Override
    public void hienthi() {

    }

    @Override
    public void timkiem() {

    }

    @Override
    public void chinhsua() {

    }
}
