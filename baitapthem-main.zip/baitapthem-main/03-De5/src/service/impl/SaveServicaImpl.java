package service.impl;

import commom.Check;
import commom.IncreaseID;
import model.BankAccount;
import model.SavingAccount;
import service.SaveServica;
import util.ReadAndWriteCSV;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import static service.impl.PayServicaImpl.scanner;

public class SaveServicaImpl implements SaveServica {
    private static final String Bank_PATH_CSV = "src/data/BankAccounts.csv";

    @Override
    public void themmoi() {
        int id = IncreaseID.increaseID();
        System.out.println(" them code");


        String code1 = "";
        do {
            System.out.println("nhập Số thẻ sử dụng");
            code1 = scanner.nextLine();
            if (Check.checRegexMTK(code1)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMTK(code1));
        int code = Integer.parseInt(code1);


//        int code ;
//        while (true) {
//            try {
//                System.out.println("nhập Mã tài khoản sử dụng");
//                code = Integer.parseInt(scanner.nextLine());
//                System.out.println("bạn đã nhập đúng ");
//                break;
//            } catch (NumberFormatException e) {
//                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
//            }
//        }


        String name = "";
        do {
            System.out.println("nhập tên");
            name = scanner.nextLine();
            if (Check.checkKhachHangName(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkKhachHangName(name));


        LocalDate dateNow = LocalDate.now();
        boolean check;
        LocalDate startDay = null;
        do {
            try {
                System.out.println("nhập ngay bắt đầu theo dd/MM/yyyy");
                String day = scanner.nextLine();
                startDay = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                Period periodToNextJavaRelease = Period.between(startDay, dateNow);
                if (periodToNextJavaRelease.getYears() < 100) {
                    System.out.println("bạn đã nhập đúng ");
                    break;
                }
                check = false;
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            } catch (DateTimeParseException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
                check = false;
            }
        } while (!check);



        String  saveMoney1 = "";
        do {
            System.out.println("nhập Số thẻ sử dụng");
            saveMoney1 = scanner.nextLine();
            if (Check.checRegexMTK( saveMoney1)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMTK( saveMoney1));

        int saveMoney= Integer.parseInt(saveMoney1);



        LocalDate dateOfSave = null;
        do {
            try {
                System.out.println("nhập ngay Ngày gửi tiết kiệm theo dd/MM/yyyy");
                String day = scanner.nextLine();
                dateOfSave = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                Period periodToNextJavaRelease = Period.between(dateOfSave, startDay);
                if (periodToNextJavaRelease.getYears() < 0) {
                    System.out.println("bạn đã nhập đúng ");
                    break;
                }
                check = false;
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            } catch (DateTimeParseException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
                check = false;
            }
        } while (!check);



        String interestAccount1 = "";
        do {
            System.out.println("nhập Số thẻ sử dụng");
            interestAccount1 = scanner.nextLine();
            if (Check.checRegexMTK( interestAccount1)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMTK( interestAccount1));
        float  interestAccount = Float.parseFloat(interestAccount1);



        LocalDate endOfSave = null;
        do {
            try {
                System.out.println("nhập ngay kết thúc tiết kiệm theo dd/MM/yyyy");
                String day = scanner.nextLine();
                endOfSave = LocalDate.parse(day, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                Period periodToNextJavaRelease = Period.between(dateNow, endOfSave);
                if (periodToNextJavaRelease.getYears() > 0) {
                    System.out.println("bạn đã nhập đúng ");
                    break;
                }
                check = false;
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            } catch (DateTimeParseException e) {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
                check = false;
            }
        } while (!check);

        List<BankAccount> bankAccountList = new ArrayList<>();
        BankAccount bankAccount = new SavingAccount(id, code, name, startDay, saveMoney, dateOfSave, interestAccount, endOfSave);
        bankAccountList.add(bankAccount);
        ReadAndWriteCSV.writeBankAccountToCSV(bankAccountList, Bank_PATH_CSV, true);

    }

    @Override
    public void hienthi() {

    }

    @Override
    public void timkiem() {

    }

    @Override
    public void chinhsua() {

    }
}
