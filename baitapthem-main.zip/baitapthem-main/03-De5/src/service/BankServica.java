package service;

public interface BankServica extends IService{
}
