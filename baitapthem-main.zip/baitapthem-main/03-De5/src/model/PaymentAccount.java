package model;

import java.time.LocalDate;

public class PaymentAccount extends BankAccount{
    private long cardNumber;
    private int moneyofAccount;

    public PaymentAccount(int idAccount, int codeAccount, String nameAccount, LocalDate dateOfStart, long cardNumber, int moneyofAccount) {
        super(idAccount, codeAccount, nameAccount, dateOfStart);
        this.cardNumber = cardNumber;
        this.moneyofAccount = moneyofAccount;
    }
    public String getInfoToCSV() {
        return super.getInfoToCSV() + "," + this.cardNumber + "," + this.moneyofAccount ;
    }
    public PaymentAccount(long cardNumber, int moneyofAccount) {
        this.cardNumber = cardNumber;
        this.moneyofAccount = moneyofAccount;
    }

    public PaymentAccount() {
    }

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getMoneyofAccount() {
        return moneyofAccount;
    }

    public void setMoneyofAccount(int moneyofAccount) {
        this.moneyofAccount = moneyofAccount;
    }

    @Override
    public String toString() {
        return "PaymentAccount{"
                + super.toString()+
                "cardNumber=" + cardNumber +
                ", moneyofAccount=" + moneyofAccount +
                "} " ;
    }
}
