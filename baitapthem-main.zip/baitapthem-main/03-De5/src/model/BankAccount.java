package model;

import java.time.LocalDate;

public abstract class BankAccount {
    private int idAccount;
    private int codeAccount;
    private String nameAccount;
    private LocalDate dateOfStart;

    public BankAccount(int idAccount, int codeAccount, String nameAccount, LocalDate dateOfStart) {
        this.idAccount = idAccount;
        this.codeAccount = codeAccount;
        this.nameAccount = nameAccount;
        this.dateOfStart = dateOfStart;
    }

    public String getInfoToCSV() {
        return this.idAccount + "," + this.codeAccount + "," + this.nameAccount + "," + this.dateOfStart;
    }

    public BankAccount() {
    }

    public int getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(int idAccount) {
        this.idAccount = idAccount;
    }

    public int getCodeAccount() {
        return codeAccount;
    }

    public void setCodeAccount(int codeAccount) {
        this.codeAccount = codeAccount;
    }

    public String getNameAccount() {
        return nameAccount;
    }

    public void setNameAccount(String nameAccount) {
        this.nameAccount = nameAccount;
    }

    public LocalDate getDateOfStart() {
        return dateOfStart;
    }

    public void setDateOfStart(LocalDate dateOfStart) {
        this.dateOfStart = dateOfStart;
    }

    @Override
    public String toString() {
        return "idAccount=" + idAccount +
                ", codeAccount=" + codeAccount +
                ", nameAccount='" + nameAccount + '\'' +
                ", dateOfStart=" + dateOfStart;
    }
}
