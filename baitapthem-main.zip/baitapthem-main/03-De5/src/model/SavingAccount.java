package model;

import java.time.LocalDate;

public class SavingAccount extends BankAccount {
    private int saveMoney;
    private LocalDate dateOfSave;
    private float interestAccount;
private LocalDate endOfSave;

    public SavingAccount(int idAccount, int codeAccount, String nameAccount, LocalDate dateOfStart, int saveMoney, LocalDate dateOfSave, float interestAccount, LocalDate endOfSave) {
        super(idAccount, codeAccount, nameAccount, dateOfStart);
        this.saveMoney = saveMoney;
        this.dateOfSave = dateOfSave;
        this.interestAccount = interestAccount;
        this.endOfSave = endOfSave;
    }

    public SavingAccount(int saveMoney, LocalDate dateOfSave, float interestAccount, LocalDate endOfSave) {
        this.saveMoney = saveMoney;
        this.dateOfSave = dateOfSave;
        this.interestAccount = interestAccount;
        this.endOfSave = endOfSave;
    }

    public String getInfoToCSV() {
        return super.getInfoToCSV() + "," + this.saveMoney + "," + this.dateOfSave + "," + this.interestAccount+ "," + this.endOfSave;
    }

    public SavingAccount() {
    }

    public int getSaveMoney() {
        return saveMoney;
    }

    public void setSaveMoney(int saveMoney) {
        this.saveMoney = saveMoney;
    }

    public LocalDate getDateOfSave() {
        return dateOfSave;
    }

    public void setDateOfSave(LocalDate dateOfSave) {
        this.dateOfSave = dateOfSave;
    }

    public float getInterestAccount() {
        return interestAccount;
    }

    public LocalDate getEndOfSave() {
        return endOfSave;
    }

    public void setEndOfSave(LocalDate endOfSave) {
        this.endOfSave = endOfSave;
    }

    public void setInterestAccount(float interestAccount) {
        this.interestAccount = interestAccount;
    }

    @Override
    public String toString() {
        return "SavingAccount{"
                + super.toString()+
                "saveMony=" + saveMoney +
                ", dateOfSave=" + dateOfSave +
                ", interestAccount=" + interestAccount +
                "} " ;
    }
}
