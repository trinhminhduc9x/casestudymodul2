package commom;

import model.BankAccount;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.Scanner;

public class IncreaseID {

    private static final String Bank_PATH_CSV = "src/data/BankAccounts.csv";
    static Scanner scanner = new Scanner(System.in);
    public static int increaseID() {
        List<BankAccount> bankAccountList = ReadAndWriteCSV.readBankAccountToCSV(Bank_PATH_CSV);
        int stt;
        if (bankAccountList.isEmpty()) {
            stt=1;
        } else {
            stt=bankAccountList.get(bankAccountList.size() - 1).getIdAccount() + 1;
        }
        return stt;
    }

}
