package commom;

import model.BankAccount;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Check {
    private static final String Bank_PATH_CSV = "src/data/BankAccounts.csv";
    private static final String NAME_REGEX = "^[A-Z][a-z]+(\\s[A-Z][a-z]+)+$";
    private static final String NUMBER_REGEX = "^\\d{16}$";
    private static final String MATK_REGEX = "^\\d{9}$";
    private static final String NB_REGEX = "^\\d+";
    public static Boolean checkKhachHangName(String name) {
        List<BankAccount> bankAccountList = ReadAndWriteCSV.readBankAccountToCSV(Bank_PATH_CSV);
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        boolean check = false;
        if (matcher.matches()) {
            check = true;
            for (int i = 0; i < bankAccountList.size(); i++) {
                if (name.equals(bankAccountList.get(i).getNameAccount())) {
                    check = false;
                    break;
                }
            }
        }
        return check;
    }
    public static Boolean checRegexNumber(String name) {
    return name.matches(NUMBER_REGEX);
    }
    public static Boolean checRegexMTK(String name) {
        Pattern pattern = Pattern.compile(MATK_REGEX);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }
    public static Boolean checRegexNB(String name) {
        Pattern pattern = Pattern.compile(NB_REGEX);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }
}
