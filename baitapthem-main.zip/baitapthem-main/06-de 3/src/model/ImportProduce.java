package model;

public class ImportProduce extends Produce{
    private int costImportProduce;
    private String cityImportProduce;
    private int taxImportProduce;

    public ImportProduce(int costImportProduce, String cityImportProduce, int taxImportProduce) {
        this.costImportProduce = costImportProduce;
        this.cityImportProduce = cityImportProduce;
        this.taxImportProduce = taxImportProduce;
    }

    @Override
    public String getInfoToCSV() {
        return super.getInfoToCSV()+ "," + this.costImportProduce+ "," + this.cityImportProduce+ "," + this.taxImportProduce;
    }

    public ImportProduce(int idProduce, int numberProduce, String nameProduce, int costByProduce, int amountProduce, String manufacturerProduce, int costImportProduce, String cityImportProduce, int taxImportProduce) {
        super(idProduce, numberProduce, nameProduce, costByProduce, amountProduce, manufacturerProduce);
        this.costImportProduce = costImportProduce;
        this.cityImportProduce = cityImportProduce;
        this.taxImportProduce = taxImportProduce;
    }

    public ImportProduce() {
    }

    public int getCostImportProduce() {
        return costImportProduce;
    }

    public void setCostImportProduce(int costImportProduce) {
        this.costImportProduce = costImportProduce;
    }

    public String getCityImportProduce() {
        return cityImportProduce;
    }

    public void setCityImportProduce(String cityImportProduce) {
        this.cityImportProduce = cityImportProduce;
    }

    public int getTaxImportProduce() {
        return taxImportProduce;
    }

    public void setTaxImportProduce(int taxImportProduce) {
        this.taxImportProduce = taxImportProduce;
    }

    @Override
    public String toString() {
        return "ImportProduce{" +
                "costImportProduce=" + costImportProduce +
                ", cityImportProduce='" + cityImportProduce + '\'' +
                ", taxImportProduce=" + taxImportProduce +
                "} " + super.toString();
    }
}
