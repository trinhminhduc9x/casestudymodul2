package model;

public abstract class Produce {
    private int idProduce;
    private int numberProduce;
    private String nameProduce;
    private int costByProduce;
    private int amountProduce;
    private String manufacturerProduce;

    public Produce() {
    }
    public Produce(int idProduce, int numberProduce, String nameProduce, int costByProduce, int amountProduce, String manufacturerProduce) {
        this.idProduce = idProduce;
        this.numberProduce = numberProduce;
        this.nameProduce = nameProduce;
        this.costByProduce = costByProduce;
        this.amountProduce = amountProduce;
        this.manufacturerProduce = manufacturerProduce;

    }


    public String getInfoToCSV() {
        return this.idProduce + "," + this.numberProduce + "," + this.nameProduce + "," + this.costByProduce + "," + this.amountProduce+ "," + this.manufacturerProduce;
    }

    public int getIdProduce() {
        return idProduce;
    }

    public void setIdProduce(int idProduce) {
        this.idProduce = idProduce;
    }

    public int getNumberProduce() {
        return numberProduce;
    }

    public void setNumberProduce(int numberProduce) {
        this.numberProduce = numberProduce;
    }

    public String getNameProduce() {
        return nameProduce;
    }

    public void setNameProduce(String nameProduce) {
        this.nameProduce = nameProduce;
    }

    public int getCostByProduce() {
        return costByProduce;
    }

    public void setCostByProduce(int costByProduce) {
        this.costByProduce = costByProduce;
    }

    public int getAmountProduce() {
        return amountProduce;
    }

    public void setAmountProduce(int amountProduce) {
        this.amountProduce = amountProduce;
    }

    public String getManufacturerProduce() {
        return manufacturerProduce;
    }

    public void setManufacturerProduce(String manufacturerProduce) {
        this.manufacturerProduce = manufacturerProduce;
    }

    @Override
    public String toString() {
        return "Produce{" +
                "idProduce=" + idProduce +
                ", numberProduce=" + numberProduce +
                ", nameProduce='" + nameProduce + '\'' +
                ", costByProduce=" + costByProduce +
                ", amountProduce=" + amountProduce +
                ", manufacturerProduce='" + manufacturerProduce + '\'' +
                '}';
    }


}
