package model;

public class ExportProduce extends Produce{
    private int costExportProduce;
    private String nationExportProduce;

    public ExportProduce(int costExportProduce, String nationExportProduce) {
        this.costExportProduce = costExportProduce;
        this.nationExportProduce = nationExportProduce;
    }

    @Override
    public String getInfoToCSV() {
        return super.getInfoToCSV()+ "," + this.costExportProduce+ "," + this.nationExportProduce;
    }

    public ExportProduce(int idProduce, int numberProduce, String nameProduce, int costByProduce, int amountProduce, String manufacturerProduce, int costExportProduce, String nationExportProduce) {
        super(idProduce, numberProduce, nameProduce, costByProduce, amountProduce, manufacturerProduce);
        this.costExportProduce = costExportProduce;
        this.nationExportProduce = nationExportProduce;
    }

    public ExportProduce() {
    }

    public int getCostExportProduce() {
        return costExportProduce;
    }

    public void setCostExportProduce(int costExportProduce) {
        this.costExportProduce = costExportProduce;
    }

    public String getNationExportProduce() {
        return nationExportProduce;
    }

    public void setNationExportProduce(String nationExportProduce) {
        this.nationExportProduce = nationExportProduce;
    }

    @Override
    public String toString() {
        return "ExportProduce{" +
                "costExportProduce=" + costExportProduce +
                ", nationExportProduce='" + nationExportProduce + '\'' +
                "} " + super.toString();
    }
}
