package commom;
import model.Produce;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Check {
    private static final String PRODUCT_PATH_CSV = "src/data/Products.csv";
    private static final String NAME_REGEX = "^[A-Z]\\w+$";
    private static final String NUMBER_REGEX = "^\\d+$";
    private static final String COUNTRY_REGEX = "[^Viet Nam]";
    private static final String MA_SANPHAM_REGEX = "^[SP000]\\d+$";

    public static Boolean checkName(String name) {
        List<Produce> produceList = ReadAndWriteCSV.readProduceToCSV(PRODUCT_PATH_CSV);
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        boolean check = false;
        if (matcher.matches()) {
            check = true;
            for (int i = 0; i < produceList.size(); i++) {
                if (name.equals(produceList.get(i).getNameProduce())) {
                    check = false;
                    break;
                }
            }
        }
        return check;
    }
    public static Boolean checRegexNumber(String name) {
        return name.matches(NUMBER_REGEX);
    }
    public static Boolean checRegexConutry(String name) {
        return name.matches(COUNTRY_REGEX);
    }
    public static Boolean checRegexMaSP(String name) {
        return name.matches(MA_SANPHAM_REGEX);
    }

}
