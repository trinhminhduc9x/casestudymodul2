package commom;
import model.Produce;
import util.ReadAndWriteCSV;

import java.util.List;
import java.util.Scanner;

public class IncreaseID {
    private static final String PRODUCT_PATH_CSV = "src/data/Products.csv";
    private static final Scanner scanner = new Scanner(System.in);
    public static int increaseID() {
        List<Produce> produceList = ReadAndWriteCSV.readProduceToCSV(PRODUCT_PATH_CSV);
        int stt;
        if (produceList.isEmpty()) {
            stt=1;
        } else {
            stt=produceList.get(produceList.size() - 1).getIdProduce()+ 1;
        }
        return stt;
    }
}
