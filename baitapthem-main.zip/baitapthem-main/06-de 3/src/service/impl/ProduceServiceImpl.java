package service.impl;

import commom.Check;
import commom.IncreaseID;
import model.ExportProduce;
import model.Produce;
import service.ProduceService;
import util.ReadAndWriteCSV;

import java.util.List;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProduceServiceImpl implements ProduceService {
    private static final String PRODUCT_PATH_CSV = "src/data/Products.csv";
    private static final Scanner scanner = new Scanner(System.in);

    @Override
    public void add() {

        List<Produce> produceList = ReadAndWriteCSV.readProduceToCSV(PRODUCT_PATH_CSV);
        for (Produce c : produceList) {
            System.out.println(c);
        }
    }

    @Override
    public void display() {
        boolean flag = true;
        do {
            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới sản phẩm nhập khẩu ." +
                    "\n 2.Thêm mới sản phẩm xuất khẩu " +
                    "\n 3. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới sản phẩm nhập khẩu");
                    addExportProduce();
                    break;
                case "2":
                    System.out.println("Thêm mới sản phẩm xuất khẩu");
                    addExportProduce();
                    break;
                case "3":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);

    }

    @Override
    public void search() {

    }

    @Override
    public void edit() {

    }

    public void addExportProduce() {
        int id = IncreaseID.increaseID();

        String number = "";
        do {
            System.out.println("nhập mã sản phẩm ");
            number = scanner.nextLine();
            if (Check.checRegexMaSP(number)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexMaSP(number));
        int numberProduce = Integer.parseInt(number);


        String name = "";
        do {
            System.out.println("nhập tên sản phẩm bắt đầu bằng chữ hoa");
            name = scanner.nextLine();
            if (Check.checkName(name)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(name));


        String giaBan = "";
        do {
            System.out.println("nhập giá bán");
            giaBan = scanner.nextLine();
            if (Check.checRegexNumber(giaBan)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(giaBan));

        int costByProduce = Integer.parseInt(giaBan);


        String soLuong = "";
        do {
            System.out.println("nhập số lượng");
            soLuong = scanner.nextLine();
            if (Check.checRegexNumber(soLuong)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(soLuong));

        int amountProduce = Integer.parseInt(soLuong);


        String manufacturerProduce = "";
        do {
            System.out.println("nhập nhà sản xuất bắt đầu bằng chữ hoa ");
            manufacturerProduce = scanner.nextLine();
            if (Check.checkName(manufacturerProduce)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(manufacturerProduce));


        String giaXuatKhau = "";
        do {
            System.out.println("nhập giá bán");
            giaXuatKhau = scanner.nextLine();
            if (Check.checRegexNumber(giaXuatKhau)) {
                System.out.println("bạn đã nhập đúng ");
            } else {
                System.out.println("bạn đã nhập sai yêu cầu nhâp lại ");
            }
        } while (!Check.checRegexNumber(giaXuatKhau));

        int costExportProduce = Integer.parseInt(giaXuatKhau);


        String nationExportProduce = "";
        do {
            System.out.println("nhập tên quốc gia sản xuất bắt đầu bằng chữ hoa");
            nationExportProduce = scanner.nextLine();
            if (Check.checkName(nationExportProduce)) {
                System.out.println(" nhập đúng tên");
            } else {
                System.out.println(" nhập không đúng tên pháp yêu cầu nhập lại");
            }
        } while (!Check.checkName(nationExportProduce));
        ;


        List<Produce> produceList = new ArrayList<>();
        Produce produce = new ExportProduce(id, numberProduce, name, costByProduce, amountProduce, manufacturerProduce, costExportProduce, nationExportProduce);
        produceList.add(produce);
        ReadAndWriteCSV.writeProduceToCSV(produceList, PRODUCT_PATH_CSV, true);

    }

}
