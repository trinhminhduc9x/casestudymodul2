package service;

public interface ProduceService extends Iservice {
}
