package service;

public interface Iservice {
    void add();
    void display();
    void search();
    void edit() ;
}
