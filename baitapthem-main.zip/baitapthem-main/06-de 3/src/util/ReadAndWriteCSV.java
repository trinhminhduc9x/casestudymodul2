package util;
import model.ExportProduce;
import model.ImportProduce;
import model.Produce;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReadAndWriteCSV {
    public static List<String> readObjectToCSV(String pathFile) {
        List<String> list = new ArrayList<>();
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(pathFile));
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                list.add(line);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    private static void writeObjectToCSV(List<String> list, String pathFile, boolean append) {
        BufferedWriter bufferedWriter = null;
        try {
            bufferedWriter = new BufferedWriter(new FileWriter(pathFile, append));
            for (int i = 0; i < list.size(); i++) {
                bufferedWriter.write(list.get(i));
                bufferedWriter.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static List<Produce> readProduceToCSV(String pathFile) {
        List<Produce> produceList = new ArrayList<>();
        List<String> list = readObjectToCSV(pathFile);
        String[] arr;
        for (int i = 0; i < list.size(); i++) {
            arr = list.get(i).split(",");
            if (arr.length==9 ){
                produceList.add(new ImportProduce(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),arr[2], Integer.parseInt(arr[3]), Integer.parseInt(arr[4]),arr[5],Integer.parseInt(arr[6]),arr[7],Integer.parseInt(arr[8])));
            } else if (arr.length==8) {
                produceList.add(new ExportProduce(Integer.parseInt(arr[0]),Integer.parseInt(arr[1]),arr[2], Integer.parseInt(arr[3]), Integer.parseInt(arr[4]),arr[5],Integer.parseInt(arr[6]),arr[7]));
            }
        }
        return produceList;
    }

    public static void writeProduceToCSV(List<Produce> produceList, String pathFile, boolean append) {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < produceList.size(); i++) {
            list.add(produceList.get(i).getInfoToCSV());
        }
        writeObjectToCSV(list, pathFile, append);
    }
}
