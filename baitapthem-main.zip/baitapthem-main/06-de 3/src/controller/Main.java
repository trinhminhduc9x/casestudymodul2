package controller;

import service.ProduceService;
import service.impl.ProduceServiceImpl;

import java.util.Scanner;

public class Main {
    public static void displayMainMenu() {
        ProduceService produceService;
        boolean flag = true;
        do {
            produceService = new ProduceServiceImpl();

            System.out.println("Chức năng của hệ thống " +
                    "\n 1.Thêm mới." +
                    "\n 2.Xóa  " +
                    "\n 3.Xem danh sách  " +
                    "\n 4.Tìm kiếm " +
                    "\n 5. Thoát");
            Scanner scanner = new Scanner(System.in);
            System.out.println("Chọn chức năng");
            String choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Thêm mới.");
                    produceService.add();
                    break;
                case "2":
                    System.out.println("Xóa thông tin ");
                    produceService.edit();
                    break;
                case "3":
                    System.out.println("Xem danh sách ");
                    produceService.display();
                    break;
                case "4":
                    System.out.println("Tìm kiếm ");
                    produceService.search();
                    break;
                case "5":
                    System.out.println("Thoát");
                    return;
                default:
                    System.out.println("yêu cầu nhập đúng số hiển thị chức năng ");
            }
        } while (flag);
    }
}
