import commom.Check;
import commom.IncreaseID;
import model.KhachHang;
import util.ReadAndWriteCSV;

import java.util.List;

public class test {
    private static final String KHACHHANG_PATH_CSV = "src/data/khachHang.csv";
    public static void main(String[] args) {

        System.out.println( IncreaseID.increaseNNID());
    }
}
