package service;

public interface ServiceKhachHang extends IService {
}
