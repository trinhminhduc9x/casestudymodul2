package service;

public interface IService {
    void themmoi();
    void hienthi();
    void timkiem();
    void chinhsua();
}
