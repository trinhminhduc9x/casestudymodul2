package service;

public interface ServicerHoaDon extends IService{
}
